import 'dotenv/config';
import express from 'express';
import session from 'express-session';
import crypto from 'node:crypto';
import { google } from 'googleapis';

const app = express();
const PORT = Number(process.env.PORT || 3000);
const BASE_URL = process.env.BASE_URL || `http://localhost:${PORT}`;
const TARGET_HANDLE = process.env.TARGET_CHANNEL_HANDLE || '@CALZ_SUKA';
const DOWNLOAD_URL = process.env.DOWNLOAD_URL || '';
const REQUIRED_SCOPES = ['openid', 'email', 'profile', 'https://www.googleapis.com/auth/youtube.readonly'];

if (!process.env.GOOGLE_CLIENT_ID || !process.env.GOOGLE_CLIENT_SECRET ||
    !process.env.YOUTUBE_API_KEY || !process.env.SESSION_SECRET) {
  console.warn('Missing config. Copy .env.example to .env and fill in the required values.');
}

const oauth = new google.auth.OAuth2(
  process.env.GOOGLE_CLIENT_ID,
  process.env.GOOGLE_CLIENT_SECRET,
  `${BASE_URL}/auth/callback`
);

app.use(session({
  name: 'calz_unlock',
  secret: process.env.SESSION_SECRET || 'development-only-change-me',
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: 'lax',
    secure: BASE_URL.startsWith('https://'),
    maxAge: 1000 * 60 * 60 * 4
  }
}));

function page({ status = 'locked', message = 'Subscribe ke channel YouTube CALZ, lalu verifikasi dengan akun Google kamu.', email = '' } = {}) {
  const unlocked = status === 'unlocked';
  return `<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#100a1f">
<title>CALZ SC V5 • Subscribe to Unlock</title>
<style>
:root{color-scheme:dark;--bg:#0b0712;--panel:#171025;--purple:#8b5cf6;--pink:#c084fc;--text:#f5f0ff;--muted:#b7abc9;--line:#35264b}
*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;padding:22px;background:radial-gradient(ellipse at top,#2b1450 0%,#100a1f 48%,#08060d 100%);font-family:system-ui,-apple-system,Segoe UI,sans-serif;color:var(--text)}
.card{width:min(100%,520px);border:1px solid var(--line);border-radius:24px;padding:26px;background:rgba(23,16,37,.94);box-shadow:0 22px 80px #0008}
.logo{width:62px;height:62px;display:grid;place-items:center;border-radius:18px;background:linear-gradient(135deg,#7c3aed,#c084fc);font-size:30px;margin-bottom:16px}
h1{margin:0;font-size:clamp(25px,7vw,34px);letter-spacing:-.7px}p{color:var(--muted);line-height:1.6}.pill{display:inline-flex;gap:8px;align-items:center;border:1px solid var(--line);padding:8px 12px;border-radius:99px;font-size:12px;font-weight:800;letter-spacing:.8px}
.dot{width:8px;height:8px;border-radius:50%;background:${unlocked ? '#4ade80' : '#fbbf24'}}
.steps{display:grid;gap:10px;margin:22px 0}.step{display:flex;gap:12px;align-items:flex-start;padding:14px;border-radius:15px;background:#0f0a19;border:1px solid #2b203c}.num{width:28px;height:28px;flex:0 0 28px;border-radius:9px;background:#33204e;display:grid;place-items:center;font-weight:800}.step b{display:block;margin:2px 0 4px}.step small{color:var(--muted);line-height:1.45}
.btn{display:flex;justify-content:center;align-items:center;text-align:center;text-decoration:none;border:0;width:100%;border-radius:13px;padding:14px 16px;margin-top:10px;background:linear-gradient(100deg,#7c3aed,#a855f7);color:white;font-weight:800;font-size:15px;cursor:pointer}
.btn.secondary{background:#241934;border:1px solid #49335f}.btn:active{transform:scale(.99)}.note{font-size:12px;border-top:1px solid var(--line);padding-top:15px;margin-top:18px}.status{margin:18px 0;padding:13px;border-radius:13px;background:${unlocked ? '#10251c' : '#2b2010'};border:1px solid ${unlocked ? '#235d3b' : '#654a1b'};line-height:1.5}.error{color:#fca5a5}.email{font-size:12px;color:#d8b4fe;overflow-wrap:anywhere}
</style>
</head><body><main class="card">
<div class="logo">🍁</div><div class="pill"><span class="dot"></span>${unlocked ? 'UNLOCKED' : 'LOCKED'} • CALZ SC V5</div>
<h1 style="margin-top:14px">Subscribe to Unlock</h1>
<p>Buka akses download CALZ SC V5 setelah status subscribe terverifikasi lewat YouTube API.</p>
<div class="status">${escapeHtml(message)}${email ? `<div class="email" style="margin-top:7px">Login: ${escapeHtml(email)}</div>` : ''}</div>
<div class="steps">
<div class="step"><span class="num">1</span><div><b>Subscribe channel CALZ</b><small>Buka channel resmi dan tekan Subscribe jika belum.</small><a class="btn secondary" href="https://www.youtube.com/@CALZ_SUKA" target="_blank" rel="noopener noreferrer">Buka YouTube @CALZ_SUKA ↗</a></div></div>
<div class="step"><span class="num">2</span><div><b>Verifikasi dengan Google</b><small>Login ke akun yang kamu gunakan untuk subscribe. Aplikasi meminta izin baca daftar subscription YouTube, bukan password akun.</small><a class="btn" href="/auth">Login & verifikasi subscribe</a></div></div>
</div>
${unlocked ? `<a class="btn" href="/download">⬇ Download CALZ SC V5</a>` : `<div class="note">Status masih terkunci. Tombol subscribe saja tidak membuka akses; sistem baru membuka download setelah pemeriksaan API berhasil.</div>`}
<div class="note">Privasi: OAuth digunakan untuk membaca subscription channel yang kamu ikuti. Token tidak ditampilkan di halaman. Keluar dan bersihkan sesi dengan tombol di bawah jika diperlukan.</div>
<a class="btn secondary" href="/logout">Keluar / reset status</a>
</main></body></html>`;
}
function escapeHtml(s='') {
  return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
app.get('/', (req, res) => res.type('html').send(page(req.session.unlock || {})));

app.get('/auth', (req, res) => {
  if (!process.env.GOOGLE_CLIENT_ID || !process.env.GOOGLE_CLIENT_SECRET) {
    return res.status(503).type('html').send(page({ message: 'OAuth belum dikonfigurasi. Admin harus mengisi GOOGLE_CLIENT_ID dan GOOGLE_CLIENT_SECRET di .env.' }));
  }
  const state = crypto.randomBytes(24).toString('hex');
  req.session.oauthState = state;
  const url = oauth.generateAuthUrl({
    access_type: 'offline',
    include_granted_scopes: true,
    prompt: 'consent',
    scope: REQUIRED_SCOPES,
    state
  });
  res.redirect(url);
});

app.get('/auth/callback', async (req, res) => {
  try {
    if (!req.query.code || !req.query.state || req.query.state !== req.session.oauthState) {
      return res.status(400).type('html').send(page({ message: 'Login tidak valid atau sesi kedaluwarsa. Coba login lagi.' }));
    }
    delete req.session.oauthState;
    const { tokens } = await oauth.getToken(String(req.query.code));
    oauth.setCredentials(tokens);
    const yt = google.youtube({ version: 'v3', auth: oauth });
    const targetResp = await yt.channels.list({
      part: ['id', 'snippet'],
      forHandle: TARGET_HANDLE,
      key: process.env.YOUTUBE_API_KEY
    });
    const target = targetResp.data.items?.[0];
    if (!target?.id) {
      return res.status(500).type('html').send(page({ message: 'Channel target tidak ditemukan. Periksa TARGET_CHANNEL_HANDLE dan YouTube API key.' }));
    }

    let token;
    let subscribed = false;
    let checked = 0;
    do {
      const params = { part: ['snippet'], mine: true, maxResults: 50 };
      if (token) params.pageToken = token;
      const resp = await yt.subscriptions.list(params);
      const items = resp.data.items || [];
      checked += items.length;
      if (items.some(item => item.snippet?.resourceId?.channelId === target.id)) {
        subscribed = true;
        break;
      }
      token = resp.data.nextPageToken || undefined;
    } while (token && checked < 500);

    const userResp = await google.oauth2({ version: 'v2', auth: oauth }).userinfo.get();
    if (subscribed) {
      req.session.unlock = { status: 'unlocked', message: 'Subscribe terverifikasi lewat YouTube API. Download sudah dibuka.', email: userResp.data.email || '' };
      req.session.downloadAllowed = true;
      req.session.save(() => res.redirect('/'));
    } else {
      req.session.unlock = { status: 'locked', message: 'Belum ditemukan subscription ke channel CALZ pada daftar akun yang login. Subscribe dulu, lalu login/verifikasi ulang.', email: userResp.data.email || '' };
      req.session.downloadAllowed = false;
      req.session.save(() => res.redirect('/'));
    }
  } catch (err) {
    console.error('YouTube verification error:', err?.response?.data || err.message);
    const code = err?.response?.status;
    const msg = code === 403
      ? 'YouTube API menolak permintaan. Periksa YouTube Data API v3, izin OAuth, dan konfigurasi Google Cloud.'
      : 'Verifikasi gagal. Coba lagi; jika tetap gagal, admin perlu memeriksa konfigurasi OAuth/API.';
    res.status(500).type('html').send(page({ message: msg }));
  }
});

app.get('/download', (req, res) => {
  if (!req.session.downloadAllowed || req.session.unlock?.status !== 'unlocked') {
    return res.status(403).type('html').send(page({ message: 'Download terkunci. Selesaikan verifikasi subscribe terlebih dahulu.' }));
  }
  if (!DOWNLOAD_URL) return res.status(500).send('DOWNLOAD_URL belum diatur di .env');
  res.redirect(DOWNLOAD_URL);
});

app.get('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/'));
});

app.listen(PORT, () => console.log(`CALZ Subscribe Unlock running at ${BASE_URL}`));
