# CALZ SC V5 — Subscribe to Unlock

Halaman dark-purple yang membuka link download hanya setelah pemeriksaan subscription lewat YouTube Data API menggunakan OAuth Google.

## Penting
- Tombol subscribe / klik "sudah subscribe" **bukan** bukti. Paket ini memeriksa daftar subscription akun yang login melalui `subscriptions.list(mine=true)`.
- Pengguna harus menyetujui izin OAuth `youtube.readonly`.
- Butuh HTTPS untuk deployment publik; jangan gunakan `http://localhost` selain pengujian lokal.
- Subscription pengguna dapat tidak terlihat jika API/izin/akun bermasalah. Sistem akan tetap terkunci bila pemeriksaan gagal.
- Jangan pernah meminta atau menyimpan password Google pengguna.
- Untuk produksi, ganti session MemoryStore Express dengan session store persisten dan aktifkan HTTPS.

## Setup
1. Instal Node.js 18 atau lebih baru.
2. Buat project di Google Cloud Console, aktifkan **YouTube Data API v3**, buat API key.
3. Buat OAuth Client ID tipe **Web application**. Tambahkan Authorized redirect URI:
   `https://DOMAIN-KAMU/auth/callback`
4. Salin `.env.example` menjadi `.env`, lalu isi:
   - `BASE_URL=https://DOMAIN-KAMU`
   - `SESSION_SECRET` dengan string acak yang panjang
   - `GOOGLE_CLIENT_ID` dan `GOOGLE_CLIENT_SECRET`
   - `YOUTUBE_API_KEY`
   - `TARGET_CHANNEL_HANDLE=@CALZ_SUKA`
   - `DOWNLOAD_URL` (sudah diisi link Drive yang diberikan)
5. Tambahkan domain ke Authorized JavaScript origins bila diminta Google OAuth, dan atur OAuth consent screen. Saat aplikasi masih dalam mode Testing, akun Google penguji harus ditambahkan sebagai test user.
6. Jalankan:
   ```bash
   npm install
   npm start
   ```
7. Buka `BASE_URL` di browser.

## Cara kerja
- `/auth` mengalihkan pengguna ke halaman login/consent Google.
- `/auth/callback` mengambil channel ID target dari handle, membaca subscription milik akun yang login, lalu mencocokkan channel ID.
- Hanya sesi yang terverifikasi yang bisa mengakses `/download`.
- Jika subscription belum ditemukan, status tetap `LOCKED`.

## Catatan server
Jangan mengunggah file `.env` ke repositori publik. Simpan client secret dan session secret hanya di server.


## Deploy gratis di Render (tanpa VPS)
1. Ekstrak ZIP ini, lalu upload **isi foldernya** ke repository GitHub baru (jangan upload ZIP sebagai satu file saja).
2. Masuk ke https://render.com dan daftar/login.
3. Pilih **New → Web Service**, sambungkan repository GitHub, lalu pilih plan **Free**.
4. Build Command: `npm install`
5. Start Command: `npm start`
6. Setelah service dibuat, salin URL HTTPS Render (misalnya `https://nama-app.onrender.com`).
7. Di Render → Environment, tambahkan semua nilai dari `.env.example`:
   - `BASE_URL` = URL HTTPS Render milikmu
   - `SESSION_SECRET` = string acak panjang yang kamu buat sendiri
   - `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `YOUTUBE_API_KEY`
   - `TARGET_CHANNEL_HANDLE` = `@CALZ_SUKA`
   - `DOWNLOAD_URL` = link Drive CALZ SC V5
8. Di Google Cloud Console, pada OAuth Client Web, tambahkan Authorized redirect URI yang **persis**:
   `https://NAMA-APP.onrender.com/auth/callback`
   Ganti dengan URL Render milikmu.
9. Aktifkan YouTube Data API v3, siapkan OAuth consent screen, dan tambahkan akun penguji jika aplikasi masih berstatus Testing.
10. Redeploy, lalu uji di browser.

## Batasan paket gratis
- Render Free dapat tidur setelah sekitar 15 menit tanpa trafik; kunjungan pertama sesudah tidur bisa lambat.
- Verifikasi subscribe asli tetap butuh setup OAuth dan YouTube API. Hosting gratis tidak menghilangkan persyaratan Google.
- Jika aplikasi OAuth masih Testing, hanya akun penguji yang bisa login; untuk membuka ke publik, cek persyaratan verifikasi Google yang berlaku.
- Jangan masukkan file `.env` atau rahasia API ke GitHub.
